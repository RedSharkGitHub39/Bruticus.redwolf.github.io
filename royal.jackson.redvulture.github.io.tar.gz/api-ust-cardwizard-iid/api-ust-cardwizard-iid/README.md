Blueprint Name
=====================
strongloop

Overview
=====================
>   This Cloud blueprint creates a RHEL6 VM, and installs node.js, strongloop and the API application (including the API framework)
>   This Cloud blueprint contains Day2 functionality for strongloop APIs

	----------------------------------
	| VM                             |
	| ------------------------------ |
	| | RHEL6                      | |
	| |  ------------------------- | |
	| |  | Nodejs                | | |
	| |  | --------------------  | | |
	| |  | | StrongPm          | | | |
	| |  | |                   | | | |
	| |  | |       API         | | | |
	| |  | |                   | | | |
	| |  | --------------------- | | |
	| |  ------------------------- | |
	| ------------------------------ |
	----------------------------------

Features
=====================
>       - Configuration for role mappings
>       - Configuration for LDAP SSO
>       - Supports Availability Zones

Inputs
======
>       - ad_security_groups: Comma delimited list of Active Directory (AD) Security Groups requiring access and permissions to the created host(s).
>               - These groups are given root access in the VM
>       - vm_size: see below
>       - vm_zone: availability zones, nova, Green_Zone, Yellow_Zone, or Red_Zone
>       - use_sticky_ips: true if reserving ip address and false if otherwise
>       - external_ip_address: static IP address for sticky IP
>       - cost_center: Cost-Center for Chargeback (Numeric only!  Do not prepend CC#).
>       - it_number: IT# for Chargeback (Do not prepend IT#).
>       - lob_name: line of business name
>       - mal_code: MAL Code for Chargeback as it appears in Application Book of Record (ABoR).
>       - nodejs_version: version of nodejs
>       - api_name: Name of Node.JS application to deploy, as defined in package.json.
>       - api_version: Version of application to deploy.  Will deploy latest version available in repo be default.
>       - api_service: Specify a service name for deployed application.  Defaults to the application name.
>       - api_instances: Number of clustered application instances. Defaults to number of vCPU instances.
>       - api_env:  List of environment variables to pass to application, specified as a comma-delimited list of '<env>=<val>' pairs. E.g.: 'API_CONF=/tmp/api_conf/DEV/conf.json,ENVIRONMENT=DEV'
>       - api_port: Specify application port. Port must be an unpriviliged port (above 1024).  By default, the application will be assigned a port of 3000 (or above), corresponding to its assigned service id.
>       - api_config: Specify the relative URL to a tar file containing application configuration files in ITS Nexus repository. Tar file will be downloaded and unpacked in the '/opt/<app_name>/<app_version>/config' directory.  Input only the portion of the repository path after: 'http://nexus.cloud.td.com/nexus/content/repositories/'. E.g.: 'LOB-Group/com/td/app/api_conf.tgz'
>       - api_hook: Specify relative path in api configuration to shell script, which will be execuated as 'strong-pm' user, before initial application deployment. E.g.: 'DEV/scripts/hook.sh'
>       - fw_tag_locations: Firewall automation locations, e.g. cloud, legacy, intercloud
>       - fw_tag_malcodes: Firewall automation application malcodes for interapplication connectivity
>       - security_context: Allows to provide a variant for application_securitygroup (part of Firewall automation) to limit network connectivity between multiple deployments under the same malcode

Sizes and Costs:
===============

The "rhel6vm" can use any of the following sizes:
----------------------------------------------------
>       - m1.tiny
>       - m1.small
>       - m1.medium
>       - m1.large
>       - m1.xlarge

Sizing recommendations
----------------------
ITS Recommends following the below sizing guidelines to ensure a successful deployment.

        +-----------+----+----------+
        |Flavor Name|vCPU|Total RAM |
        +-----------+----+----------+
        |m1.tiny    | 1  | 512 MB   |
        |m1.small   | 1  | 2048 MB  |
        |m1.medium  | 2  | 4096 MB  |
        |m1.large   | 4  | 8192 MB  |
        |m1.xlarge  | 8  | 16384 MB |
        +-----------+----+----------+


See the following link regarding Sizes and associated costs for hosting RHEL on TD Cloud:
---------------------------------------------------------------------------------------------
http://w8.teamworks.td.com/Teams/Cloud/Documents/Cloud%20Virtual%20Machine%20Sizes%20and%20Pricing.pdf


Quick Start Guide
=====================
http://w8.teamworks.td.com/Teams/Cloud/Documents/RHEL%206%20Cloud%20Quickstart.pdf