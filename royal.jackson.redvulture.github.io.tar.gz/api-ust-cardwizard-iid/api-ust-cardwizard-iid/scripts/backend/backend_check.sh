-------------------------------------------------------
# Check Backend Connections
#-------------------------------------------------------
exec > /tmp/backend_check.out 2>&1

# Retrieving properties from /etc/salt/grains
mal_code=$(awk '/mal_code:/ {print $2}' /etc/salt/grains)
echo "MALCode =" $mal_code
vm_ip=$(awk '/floating_ip_address:/ {print $2}' /etc/salt/grains)
echo "  VM IP =" $vm_ip
env_name=$(awk '/environment:/ {print $2}' /etc/salt/grains)
echo "    ENV =" $env_name
date_time=`date --utc +%F%Z%T`

# Add curl commands here for each environment
if [ "$env_name" = "prod" ] ; then
    ##CardWizard PROD
    curl -v https://cardwizardapi.td.com
    curl -v 10.105.255.33 
    ##SPLUNK PROD
    curl -v 10.112.216.10:9997
    curl -v 10.112.216.11:9997
    curl -v 10.112.216.12:9997
    curl -v 10.112.216.19:9997
    curl -v 10.112.216.22:9997
    curl -v 10.112.216.23:9997
    curl -v 10.211.153.1:9997
    curl -v 10.211.153.2:9997
    curl -v 10.105.194.160:9997
    curl -v 10.105.194.161:9997
    curl -v 10.105.194.165:9997
    curl -v 10.105.194.170:9997
    curl -v 10.206.153.1:9997
    curl -v 10.206.153.2:9997
    curl -v 10.112.216.17:8089
elif [ "$env_name" = "pat" ] ; then
    ##CardWizard PAT
    curl -v https://cardwizardapi.pat.td.com
    curl -v 10.110.223.29
    ##SPLUNK PAT
    curl -v 10.157.248.178:9997
    curl -v 10.157.248.179:9997
    curl -v 10.157.248.180:9997
    curl -v 10.157.248.181:9997
    curl -v 10.157.248.183:8089
elif [ "$env_name" = "sit0" ] ; then
    ##SIT Connection
elif [ "$env_name" = "dev" ] ; then
    ##DEV Connection
fi

sudo mv /tmp/backend_check.out /var/splunked/adapters/
sudo chown cloud-user:cloud-user /var/splunked/adapters/backend_check.out
sudo touch /var/splunked/adapters/backend_check.log
sudo chown cloud-user:cloud-user /var/splunked/adapters/backend_check.log
egrep "About to connect|Connected to|Connection timed out" /var/splunked/adapters/backend_check.out | sed "s/^/{\"level\":\"backend_check\",\"message\":\"/g" | sed "s/$/\",\"timestamp\":\"$date_time\"}/g" > /var/splunked/adapters/backend_check.log

exit
