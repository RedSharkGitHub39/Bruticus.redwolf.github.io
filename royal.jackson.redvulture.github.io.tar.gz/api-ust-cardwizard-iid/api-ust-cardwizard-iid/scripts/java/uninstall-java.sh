#!/bin/bash

#TEMP_DIR="/tmp"
#YUM_CMD=$(which yum)


ctx logger info "attempting to install JAVA - JJMILLER"

##   sudo mv ${DEPLOYMENT} ${JBOSS_DEPLOY} || exit $?
sudo yum --quiet --assumeyes erase java-1.7.*
ctx logger info "done Installing Java- JJMILLER" 
ctx logger info "Finished installing JAVA-JJMILLER"
