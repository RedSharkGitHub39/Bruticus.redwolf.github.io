#!/bin/bash

export PATH=$PATH:/opt/nodejs/bin
export HOME=/home/cloud-user

# indicator for "node" process
found=0
env_list="dev sit pat prod"

env_name_list=$(awk '/environment:/ {print $2}' /etc/salt/grains)
env_name=`echo $env_name_list | awk '{print $NF}'`
 
# determines which environment the script is running on
for l_env_name in $env_list
do
   check_env=`echo $env_name | grep -i $l_env_name`

   if [[ ! -z $check_env ]]
   then
      env_found=$l_env_name
      break
   fi
done

# selects appropriate cluster size
case $env_found in
   dev | sit)
      CLUSTER_SIZE=3
      ;;

   pat | prod)
      CLUSTER_SIZE=48
      ;;
esac

# waits for "node" process to execute
while [ $found -eq 0 ]
do
   # retrieves running process with the name "node"
   check=`ps -e | grep ' node' | awk '{print $NF}'`
   check=`echo $check | awk '{print $NF}'`

    # sets the cluster size to 48 if the process is running
    if [ "$check" = "node" ]
    then
       echo -e "Background process \"cknode.sh\" has confirmed api-ust-parties-rm API has started\nSetting the cluster size to 48"
       found=1
       sleep 10

       sudo touch /home/output
       sudo chmod 646 /home/output

       service_name=`sl-pmctl --control http://admin:admin@localhost:8701 status | grep "Service Name: " | awk '{print $NF}'`

       

       sl-pmctl --control http://admin:admin@localhost:8701 set-size $service_name $CLUSTER_SIZE > /home/output
    fi
done
