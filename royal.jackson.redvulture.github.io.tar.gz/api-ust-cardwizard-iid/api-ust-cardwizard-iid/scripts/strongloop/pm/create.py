from cloudify import ctx
from imp import load_source
import os

def Main():

    fn = load_common_functions()

    role = "strongpm"
    version = ctx.node.properties['strongpm_version']

    ctx.logger.info("(x)::::[]>>>>>>>>> BEGIN: strongloop/pm/create.py <<<<<<<<<<<<[]::::(x)")

    fn.log("Setting minion grains")
    fn.run("sudo salt-call grains.setval {0}_version {1}".format(role, version))
            
    fn.log("Setting minion roles grain")
    fn.run("sudo salt-call grains.append roles \'{0}\'".format(role))

    fn.log("Calling state.highstate for configuration")
#    fn.run("sudo salt-call state.highstate", False, 600, 3)
    fn.run("sudo salt-call state.highstate", False)

    ctx.logger.info("(x)::::[]>>>>>>>>>>> END: strongloop/pm/create.py <<<<<<<<<<<<[]::::(x)")


def load_common_functions():
    """
    Loads the common functions from /tmp/functions.py and downloads functions.py if it is missing.
    """
    if not os.path.isfile('/tmp/functions.py'):
        ctx.download_resource('scripts/common/functions.py', '/tmp/functions.py')
    return load_source('functions', '/tmp/functions.py')


Main()

