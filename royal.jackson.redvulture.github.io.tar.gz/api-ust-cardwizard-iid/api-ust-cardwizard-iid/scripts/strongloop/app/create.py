from cloudify import ctx
from imp import load_source
import os
import json

def Main():

    fn = load_common_functions()

    app = {}
    app['name'] = ctx.node.properties['app_name']
    app['version'] = ctx.node.properties['app_version']
    app['service'] = ctx.node.properties['app_service']
    app['instances'] = ctx.node.properties['app_instances']
    if ctx.node.properties['app_env'] == 0:
        app['env'] = ctx.node.properties['app_env']
    else:
        app['env'] = []
        app['env'] = ctx.node.properties['app_env'].split(',')
    app['port'] = ctx.node.properties['app_port']
    app['config'] = ctx.node.properties['app_config']
    app['hook'] = ctx.node.properties['app_hook']

    ctx.logger.info("(x)::::[]>>>>>>>>> BEGIN: strongloop/app/create.py <<<<<<<<<<<<[]::::(x)")

    fn.log("Retrieved application to install: '{0}'".format(app['name']))

    for key, value in app.iteritems():
            ctx.logger.info("Retrieved application properties: {0}: {1}".format(key, value))

    fn.log("Setting minion 'deploy' grain: '{0}'".format(app))
    fn.run("sudo salt-call grains.setval deploy \'{0}\'".format(json.dumps(app)))

    fn.log("Calling salt state strongloop.deploy for Application configuration")
#    fn.run("sudo salt-call state.sls strongloop.deploy", False, 600, 3)
    fn.run("sudo salt-call state.sls strongloop.deploy", False)

    fn.log("setting runtime_property 'app_info' with minion data from grain: 'deployed:{0}'".format(app['name']))
    ctx.instance.runtime_properties['app_info'] = fn.run("sudo salt-call grains.get --out=raw \'deployed:{0}\'".format(app['name']), True, 600, 3)

    fn.log("Deleting minion grain: 'deploy'")
    fn.run("sudo salt-call grains.delval \'{0}\' destructive=True".format('deploy'), False, 600, 3)

    ctx.logger.info("(x)::::[]>>>>>>>>>>> END: strongloop/app/create.py <<<<<<<<<<<<[]::::(x)")


def load_common_functions():
    """
    Loads the common functions from /tmp/functions.py and downloads functions.py if it is missing.
    """
    if not os.path.isfile('/tmp/functions.py'):
        ctx.download_resource('scripts/common/functions.py', '/tmp/functions.py')
    return load_source('functions', '/tmp/functions.py')


Main()

