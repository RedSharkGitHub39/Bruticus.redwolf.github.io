#-------------------------------------------------------
# Setup CTS SPLUNK Configuraiton and Connectivity
#-------------------------------------------------------
exec > /tmp/cts_splunk_setup.log 2>&1
set -x

sudo rm /opt/splunkforwarder/etc/system/local/outputs.conf
sudo rm -rf /opt/splunkforwarder/etc/apps/salt
#sudo rm -rf /opt/splunkforwarder/etc/apps/ta-jboss
sudo rm /opt/splunkforwarder/etc/apps/search/local/inputs.conf
sudo rm -rf /opt/splunkforwarder/etc/apps/nonsox_legacy_cluster_forwarder_outputs

# Retrieving properties from /etc/salt/grains
mal_code=$(awk '/mal_code:/ {print $2}' /etc/salt/grains)
vm_ip=$(awk '/floating_ip_address:/ {print $2}' /etc/salt/grains)
env_name=$(awk '/environment:/ {print $2}' /etc/salt/grains)

# Download and unzip td_cts_deployment_client.zip to /opt/splunkforwarder/etc/apps/
ctx download-resource scripts/splunk/td_cts_deployment_client.zip  /tmp/td_cts_deployment_client.zip
sudo unzip -o /tmp/td_cts_deployment_client.zip -d /opt/splunkforwarder/etc/apps/

# Update /opt/splunkforwarder/etc/apps/td_cts_deployment_client/local/deploymentclient.conf
deploymen_client_conf=/opt/splunkforwarder/etc/apps/td_cts_deployment_client/local/deploymentclient.conf
sudo sed -i '/^clientName/c\clientName='${env_name}'_AMCB_'${mal_code}'_linux' ${deploymen_client_conf}

    if [ "$env_name" = "prod" ] ; then
        sudo sed -i '/^targetUri/c\targetUri = 10.112.216.17:8089' ${deploymen_client_conf}
    elif [ "$env_name" = "pat" ] ; then
        sudo sed -i '/^targetUri/c\targetUri = 10.157.248.183:8089' ${deploymen_client_conf}
    else
        sudo sed -i '/^targetUri/c\targetUri = 10.158.105.248:8089' ${deploymen_client_conf}
    fi

#Update /opt/splunkforwarder/etc/splunk-launch.conf and set SPLUNK_OS_USER=splunk   <<<<---skipping to allow splunk to run as root #####

#        sudo sed -i '/SPLUNK_OS_USER=splunk/d' /opt/splunkforwarder/etc/splunk-launch.conf
#        sudo sed -i '/^MONGOC_DISABLE_SHM/i\SPLUNK_OS_USER=splunk' /opt/splunkforwarder/etc/splunk-launch.conf

# Update /opt/splunkforwarder/etc/system/local/inputs.conf

sudo sed -i '/host/a \_meta = lob::amcb mal::'${mal_code}' hostip::'${vm_ip}'' /opt/splunkforwarder/etc/system/local/inputs.conf

# restart splunk

sudo chown -R splunk:splunk /opt/splunkforwarder/
sudo ps aux|grep "[splunkd] pid"| awk '{print $2}'|sudo xargs kill
sudo /opt/splunkforwarder/bin/splunk stop
sleep 30
sudo /opt/splunkforwarder/bin/splunk start

#sudo /opt/splunkforwarder/bin/splunk btool inputs list --debug
sudo ls -l /opt/splunkforwarder/etc/system
sudo cat /opt/splunkforwarder/etc/system/local/inputs.conf

